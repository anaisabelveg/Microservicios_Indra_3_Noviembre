package es.indra.business;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import es.indra.clients.PedidosClienteFeign;
import es.indra.entity.Carrito;
import es.indra.models.Pedido;
import es.indra.persistence.CarritosDAO;

@Service
public class CarritoBSImpl implements ICarritoBS{
	
	@Autowired
	private CarritosDAO dao;
	
	@Autowired
	private PedidosClienteFeign clienteFeign;

	@Override
	public Carrito crear(String usuario) {
		// Solo creo el carrito si no existe para ese usuario
		Carrito carrito = consultar(usuario);
		
		if (carrito == null) {
			carrito = new Carrito();
			carrito.setUsuario(usuario);
			return dao.save(carrito);
		}
		return carrito;
	}

	@Override
	public Carrito consultar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public Carrito agregarPedido(Long id, Integer cantidad, String usuario) {
		Pedido pedido = clienteFeign.crear(id, cantidad);
		Carrito carrito = consultar(usuario);
		carrito.getContenido().add(pedido);
		double importePedido = pedido.getProducto().getPrecio() * cantidad;
		carrito.setImporte(importePedido + carrito.getImporte());
		return dao.save(carrito);
	}

	@Override
	public Carrito eliminarPedido(Long id, String usuario) {
		Carrito carrito = consultar(usuario);
		List<Pedido> contenido = carrito.getContenido();
		
		// Opcion 1: ******************* Solo elimino el primer pedido de ese producto  ********************
		
		// Recorrer con bucle for
//		Pedido encontrado = null;
//		for (Pedido pedido : contenido) {
//			if (pedido.getProducto().getID() == id) {
//				encontrado = pedido;
//				break;
//			}
//		}
		
		// Streams de Java 8
		Pedido encontrado = contenido.stream()
				.filter(pedido -> pedido.getProducto().getID() == id)
				.findFirst()
				.get();
		
		contenido.remove(encontrado);
		double importePedido = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importePedido);
		return dao.save(carrito);
		
		
		// Opcion 2: ******************* Elimino todos los pedidos de ese producto  ********************
//		List<Pedido> encontrados = contenido.stream()
//				.filter(pedido -> pedido.getProducto().getID() == id)
//				.collect(Collectors.toList());
//		
//		double importeARestar = encontrados.stream()
//				.mapToDouble(pedido -> pedido.getProducto().getPrecio() * pedido.getCantidad())
//				.sum();
//		carrito.setImporte(carrito.getImporte() - importeARestar);
//		
//		contenido.removeIf(pedido -> id == pedido.getProducto().getID());
//		return dao.save(carrito);
	}

}











