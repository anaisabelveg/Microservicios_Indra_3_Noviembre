package es.indra.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

import es.indra.business.ICarritoBS;
import es.indra.entity.Carrito;

@RestController
public class CarritoREST {
	
	@Autowired
	private ICarritoBS bs;
	
	// http://localhost:8003/crear/Anabel
	@PostMapping("/crear/{usuario}")
	public Carrito crear(@PathVariable String usuario) {
		return bs.crear(usuario);
	}
	
	// http://localhost:8003/consultar/Anabel
	@GetMapping("/consultar/{usuario}")
	public Carrito consultar(@PathVariable String usuario) {
		return bs.consultar(usuario);
	}
	
	// http://localhost:8003/agregar/id/2/cantidad/100/usuario/Anabel
	@PutMapping("/agregar/id/{id}/cantidad/{cantidad}/usuario/{usuario}")
	public Carrito agregarPedido(@PathVariable Long id, @PathVariable Integer cantidad, @PathVariable String usuario) {
		return bs.agregarPedido(id, cantidad, usuario);
	}
	
	// http://localhost:8003/eliminar/id/2/usuario/Anabel
	@DeleteMapping("/eliminar/id/{id}/usuario/{usuario}")
	public Carrito eliminarPedido(@PathVariable Long id, @PathVariable String usuario) {
		return bs.eliminarPedido(id, usuario);
	}

}
