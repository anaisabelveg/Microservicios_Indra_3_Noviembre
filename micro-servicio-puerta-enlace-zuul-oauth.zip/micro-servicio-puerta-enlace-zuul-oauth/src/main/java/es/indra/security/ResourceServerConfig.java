package es.indra.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configurers.ResourceServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;

@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter{
	
	@Bean
	public JwtTokenStore tokenStore() {
		return new JwtTokenStore(accessTokenConverter());
	}
	
	@Bean
	public JwtAccessTokenConverter accessTokenConverter() {
		JwtAccessTokenConverter tokenConverter = new JwtAccessTokenConverter();
		tokenConverter.setSigningKey("pepito_12345_aeiou");
		return tokenConverter;
	}
	
	@Override
	public void configure(HttpSecurity http) throws Exception {
		// Configuramos las url que autorizamos segun los roles de cada usuario
		// java.lang.IllegalArgumentException: role should not start with 'ROLE_' since it is automatically inserted. Got 'ROLE_ADMIN'
		http.authorizeRequests(
				request -> request.antMatchers("/api/security/oauth/**").permitAll()
					.antMatchers(HttpMethod.GET, "/api/productos/listar").permitAll()
					.antMatchers(HttpMethod.GET, "/api/carrito/consultar/{usuario}").hasAnyRole("ADMIN","USER")
					.antMatchers(HttpMethod.GET, "/api/pedidos/**").hasRole("ADMIN")
					.antMatchers(HttpMethod.GET, "/api/productos/**").hasAnyRole("ADMIN","USER")
					.antMatchers(HttpMethod.GET, "/api/carrito/**").hasAnyRole("ADMIN","USER")
					.anyRequest().authenticated()
				);
	}
	
	@Override
	public void configure(ResourceServerSecurityConfigurer resources) throws Exception {
		resources.tokenStore(tokenStore());
	}

}






