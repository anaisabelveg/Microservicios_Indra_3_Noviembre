package es.indra.clients;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import es.indra.models.Usuario;

@FeignClient(name = "servicio-usuarios")
public interface UsuariosClienteFeign {
	
	// Mapear a donde vamos a emitir la peticion
	@GetMapping(path = "/usuarios/search/buscar-username")
	public Usuario findByUsername(@RequestParam String username);

}
