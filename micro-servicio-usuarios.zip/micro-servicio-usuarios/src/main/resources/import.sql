INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('juan', '$2a$10$eezAIqd9PRUOU.7PsrAXVO/NzyqaT3Vk5jbTK0T9hz7aduRyVMu7m', 1, 'Juan', 'Lopez', 'juan@gmail.com');
INSERT INTO usuarios (username, password, enabled, nombre, apellido, email) values ('admin', '$2a$10$wobCxwuR0hCiZ.AtofDM8eYLhyHWBTqX3Jblr8nRnL5CgjDHupKve', 1, 'Maria', 'Rodriguez', 'maria@gmail.com');

INSERT INTO roles (nombre) VALUES ('ROLE_USER');
INSERT INTO roles (nombre) VALUES ('ROLE_ADMIN');

INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (1,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,1);
INSERT INTO usuarios_roles (usuario_id, role_id) VALUES (2,2);